package com.liang.model;

import java.io.Serializable;

/**
 * Created by liangxj on 2016/6/4.
 */
public class Role implements  Serializable{

    private Long id;
    private String name;
    private Long createBy;
    private Long upateBy;
    private Long createAt;
    private Long updateAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    public Long getUpateBy() {
        return upateBy;
    }

    public void setUpateBy(Long upateBy) {
        this.upateBy = upateBy;
    }

    public Long getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Long createAt) {
        this.createAt = createAt;
    }

    public Long getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(Long updateAt) {
        this.updateAt = updateAt;
    }
}
