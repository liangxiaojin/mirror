package com.liang.service.impl;

import com.liang.dao.ManagerMapper;
import com.liang.model.Manager;
import com.liang.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * Created by liangxj on 2016/6/4.
 */
@Service
public class ManagerServiceImpl implements ManagerService {
    @Autowired
    private ManagerMapper managerMapper;

    public Manager getManagerById(Long id) {
        System.out.println(" id = "+id);
        System.out.println(" managerMapper = " + managerMapper);
        return managerMapper.getManagerById(id);
    }

    public void updateManagerById(Long id, String name) {
        managerMapper.updateManagerById(id,name);
    }

}
