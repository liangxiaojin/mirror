package com.liang.service;

import com.liang.model.Manager;
import org.springframework.stereotype.Service;

/**
 * Created by liangxj on 2016/6/4.
 */

public interface ManagerService {

     Manager getManagerById(Long id);

    void updateManagerById(Long id,String name);
}
