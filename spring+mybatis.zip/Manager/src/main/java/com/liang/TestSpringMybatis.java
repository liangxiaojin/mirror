package com.liang;

import com.liang.model.Manager;
import com.liang.service.ManagerService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.junit.Before;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by liangxj on 2016/6/4.
 */

public class TestSpringMybatis {
    private ApplicationContext applicationContext = null;
    private ManagerService managerService;

    @Before
    public void before(){
        //手动加载spring配置文件
        applicationContext = new ClassPathXmlApplicationContext("spring-mybatis.xml");
        managerService = (ManagerService) applicationContext.getBean("managerServiceImpl");
    }
    @Test
    public void test(){
        Manager manager =  managerService.getManagerById(2L);
        System.out.println(manager.getName());
    }


}
