package com.liang.dao;

/**
 * Created by liangxj on 2016/6/4.
 */
public @interface LiangAnnotation {
    String value() default "";
}
