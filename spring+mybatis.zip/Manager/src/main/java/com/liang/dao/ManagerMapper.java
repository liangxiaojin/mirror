package com.liang.dao;

import com.liang.model.Manager;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * Created by liangxj on 2016/6/4.
 */
@LiangAnnotation
public interface ManagerMapper {// extends BaseMapper{
    @Select(" select * from manager where id = #{id}")
     Manager getManagerById(Long id);

    @Update(" update manager set name = #{name} where id = #{id}")
     void updateManagerById(Long id,String name);

//    @Update(" update manager set name = #{name} where id = #{id}")
//    public void updateManagerBatch(String anme);

}
