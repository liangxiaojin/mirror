package com.liang;

import com.liang.model.Manager;
import com.liang.service.ManagerService;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


/**
 * Created by liangxj on 2016/6/4.
 */
@Ignore
public class TestSpringMybatis {
    private static Logger logger  =Logger.getLogger(TestSpringMybatis.class);

    private ApplicationContext applicationContext = null;
    private ManagerService managerService;

    @Before
    public void before(){
        //手动加载spring配置文件
        applicationContext = new ClassPathXmlApplicationContext("spring-mybatis.xml");

      //  managerService = (ManagerService) applicationContext.getBean("managerServiceImpl");
    }
    @Test
    public void test(){
//        Manager manager =  managerService.getManagerById(2L);
       // System.out.println(manager.getName()+" logger = "+logger);
     //   logger.info(manager.getName());

        try {
            ManagerService managerService = (ManagerService) Naming.lookup("//localhost:8020/managerService");
            logger.info(" managerService = "+Naming.lookup("//localhost:8020/managerService"));
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


}
