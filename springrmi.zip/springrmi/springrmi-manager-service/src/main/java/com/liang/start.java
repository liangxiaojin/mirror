package com.liang;

import com.liang.dao.ManagerMapper;
import com.liang.service.ManagerService;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

/**
 * Created by liangxj on 2016/6/6.
 */
public class start {
    private static Logger logger = Logger.getLogger(start.class);
    public static void main(String[] args) throws InterruptedException {
        ApplicationContext applicationContext =  new ClassPathXmlApplicationContext("spring-mybatis.xml");
        ApplicationContext applicationContext1 =  new ClassPathXmlApplicationContext("spring-rmi-server.xml");
        ManagerMapper managerMapper = (ManagerMapper) applicationContext.getBean("managerMapper");
        logger.info(" managerMapper1 =  "+managerMapper);
        //ManagerMapper managerMapper1 = (ManagerMapper) applicationContext1.getBean("managerMapper");
       // logger.info(" managerMapper2 =  "+managerMapper1);

        logger.info(" 发布服务成功");
//      Object lock = new Object();
//        synchronized (lock) {
//          lock.wait();
//      }

    }

}
