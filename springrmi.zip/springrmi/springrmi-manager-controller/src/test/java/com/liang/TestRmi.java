package com.liang;

import com.liang.model.Manager;
import com.liang.service.ManagerService;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by liangxj on 2016/6/6.
 */
public class TestRmi {

    private static Logger logger = Logger.getLogger(TestRmi.class);

    public static void main(String[] args){

       // ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-mvc.xml");
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-rmi-client.xml");

        ManagerService managerService = (ManagerService) applicationContext.getBean("managerService");
        Manager manager =  managerService.getManagerById(2L);
        logger.info(" manager name = "+manager.getName());
    }
}
