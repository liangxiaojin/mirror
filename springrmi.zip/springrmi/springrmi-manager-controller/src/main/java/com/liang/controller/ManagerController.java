package com.liang.controller;

import com.liang.model.Manager;
import com.liang.service.ManagerService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by liangxj on 2016/6/6.
 */
@Controller
@RequestMapping("/manager")
public class ManagerController {
    private static  Logger logger = Logger.getLogger(ManagerController.class);
    @Autowired
    private ManagerService managerService;

    @RequestMapping( value = "/test/{id}" ,method = RequestMethod.GET)
    public String getManagerById(HttpServletRequest request,HttpServletResponse response
            ,ModelMap modelMap, @PathVariable Long id){
        logger.info(" id = "+id);
        Manager manager =  managerService.getManagerById(id);
        logger.info(" manager name = "+manager.getName());
        modelMap.addAttribute("manager",manager);
        return "manager";
    }

}
