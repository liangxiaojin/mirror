package com.liang.model.mapper;

import com.liang.model.Manager;
import org.apache.ibatis.annotations.Select;

/**
 * Created by liangxj on 2016/6/4.
 */
public interface managerMapper {


    public Manager  getManagerById(Long id);
}
