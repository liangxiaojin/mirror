package com.liang.service.manager.manager;

import com.liang.model.Manager;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * Created by liangxj on 2016/6/3.
 */
public interface ManagerService {


    public Manager getManagerById(Long id);

    public List<Manager> getAll();
}
