package com.liang.service.manager;

import com.liang.model.Manager;
import com.liang.model.mapper.managerMapper;
import com.liang.service.manager.manager.ManagerService;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * Created by liangxj on 2016/6/3.
 */
public class TestManager {

    public static  void main(String[] args){
        String resource = "conf.xml";
        InputStream inputStream =  TestManager.class.getClassLoader().getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession =  sqlSessionFactory.openSession();
        String sql = "com.liang.model.mapper.managerMapper.getManagerById";
        Manager manager =  sqlSession.selectOne(sql, 2L);
        System.out.print(manager.getName());
    }

    @Test
    public void getManagerById(){
        //mapper配置文件
        String resource = "conf.xml";
        InputStream inputStream =  TestManager.class.getClassLoader().getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession =  sqlSessionFactory.openSession();
      //  String sql = "com.liang.model.mapper.managerMapper.getManagerById";
    //    Manager manager =  sqlSession.selectOne(sql,2L);
        managerMapper managerMapper =  sqlSession.getMapper(managerMapper.class);
        Manager manager = managerMapper.getManagerById(2L);
        sqlSession.close();
        System.out.print(manager.getName());
    }

}
